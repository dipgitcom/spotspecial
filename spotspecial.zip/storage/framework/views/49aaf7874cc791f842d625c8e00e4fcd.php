<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card shadow-sm">
                <div class="card shadow-sm mb-2">
                        <div class="card-header text-white text-center ">
                            <h3 class="mb-0">
                                All Posts
                            </h3>
                        </div>
                    </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success mb-3"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table id="posts-table" class="table table-hover align-middle table-bordered">
                            <thead class="table-light">
                                <tr>
                                    <th>ID</th>
                                    <th>Title</th>
                                    <th>Type</th>
                                    <th>User</th>
                                    <th>Status</th>
                                    <th>Created At</th>
                                    <th style="width:160px;">Action</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="postDetailModal" tabindex="-1" aria-labelledby="postDetailLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="postDetailLabel">Post Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div id="post-detail-content"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<link rel="stylesheet" href="//cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="//cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
$(function () {
    const table = $('#posts-table').DataTable({
        processing: true,
        serverSide: true,
        ajax: '<?php echo e(route("post_manage.data")); ?>',
        columns: [
            { data: 'id', name: 'id' },
            { data: 'title', name: 'title' },
            { data: 'post_type', name: 'post_type', render: function(data){
                return `<span class="badge bg-info">${data.charAt(0).toUpperCase() + data.slice(1)}</span>`;
            }},
            { data: 'user_name', name: 'user.name' },
            { data: 'status', name: 'status', render: function(data){
                if (data === 'published') return `<span class="badge bg-success">Published</span>`;
                if (data === 'draft') return `<span class="badge bg-warning">Draft</span>`;
                return `<span class="badge bg-secondary">${data.charAt(0).toUpperCase() + data.slice(1)}</span>`;
            }},
            { data: 'created_at', name: 'created_at' },
            { data: 'action', name: 'action', orderable: false, searchable: false }
        ]
    });

    // Delete button with SweetAlert confirmation
    $(document).on('click', '.btn-delete', function(e){
        e.preventDefault();
        const url = $(this).data('url');
        Swal.fire({
            title: 'Are you sure?',
            text: 'This post will be deleted permanently!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            confirmButtonText: 'Delete',
            cancelButtonText: 'Cancel'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: url,
                    type: 'DELETE',
                    data: { _token: '<?php echo e(csrf_token()); ?>' },
                    success: function(response){
                        Swal.fire('Deleted!', response.message, 'success');
                        table.ajax.reload(null, false);
                    },
                    error: function(xhr){
                        Swal.fire('Error!', xhr.responseJSON.message || 'Post could not be deleted.', 'error');
                    }
                });
            }
        });
    });

    // View button - Load post info via AJAX and show modal
    $(document).on('click', '.btn-view', function(e){
        e.preventDefault();
        const url = $(this).data('url');
        $.get(url, function(data){
            let mediaHtml = '';
            if(data.media && data.media.length) {
                mediaHtml += '<div class="row">';
                data.media.forEach(media => {
                    mediaHtml += '<div class="col-md-4 mb-2">';
                    if(media.media_type === 'image'){
                        mediaHtml += `<img src="${media.image_url}" class="img-fluid rounded mb-1" alt="Image">`;
                    } else if(media.media_type === 'video'){
                        mediaHtml += `<video src="${media.video_url}" controls class="w-100"></video>`;
                    }
                    mediaHtml += '</div>';
                });
                mediaHtml += '</div>';
            } else {
                mediaHtml = '<div>No media attached.</div>';
            }

            let commentsHtml = `<h6>Comments (${data.comments.length}):</h6>`;
            if(data.comments.length){
                data.comments.forEach(comment => {
                    commentsHtml += `<div class="mb-2"><strong>${comment.user}:</strong> ${comment.comment}</div>`;
                });
            } else {
                commentsHtml += '<span>No comments.</span>';
            }

            const statusBadgeClass = data.status === 'published' ? 'success' : (data.status === 'draft' ? 'warning' : 'secondary');

            $('#post-detail-content').html(`
                <h5>${data.title}</h5>
                <p>
                  <span class="badge bg-info">${data.post_type.charAt(0).toUpperCase() + data.post_type.slice(1)}</span>
                  <span class="badge bg-${statusBadgeClass}">
                    ${data.status.charAt(0).toUpperCase() + data.status.slice(1)}
                  </span>
                </p>
                <p><strong>User:</strong> ${data.user_name}</p>
                <p><strong>Tag:</strong> ${data.tag_name}</p>
                <p><strong>Location:</strong> Lat: ${data.post_latitude}, Long: ${data.post_longitude}, Radius: ${data.incident_radius} mi</p>
                <p><strong>Created:</strong> ${data.created_at}</p>
                <hr>
                <h6>Attached Media:</h6>
                ${mediaHtml}
                <hr>
                ${commentsHtml}
            `);
            $('#postDetailModal').modal('show');
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/dipraj-dhar/Downloads/Telegram Desktop/screnzo/resources/views/backend/layouts/posts/index.blade.php ENDPATH**/ ?>