
<?php $__env->startSection('title', 'Process Steps'); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row mb-4">
        <!-- Section Meta Edit -->
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5>Edit Section Title & Subtitle</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('process-step-section.update')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-2">
                            <label class="form-label">Section Title</label>
                            <input name="title" value="<?php echo e($section->title ?? ''); ?>" class="form-control" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Section Subtitle</label>
                            <input name="subtitle" value="<?php echo e($section->subtitle ?? ''); ?>" class="form-control">
                        </div>
                        <button class="btn btn-success w-100">Update Section</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- Add Process Step -->
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5>Add Process Step</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('process-steps.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-2">
                            <label class="form-label">Title</label>
                            <input name="title" class="form-control" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Description</label>
                            <textarea name="description" class="form-control" required></textarea>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Step Number</label>
                            <input name="step_number" type="number" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-success w-100">Add Step</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Process Steps List -->
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5>All Process Steps</h5>
                </div>
                <div class="card-body p-0">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success m-3"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th>Step</th>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($step->step_number); ?></td>
                                <td><?php echo e($step->title); ?></td>
                                <td><?php echo e($step->description); ?></td>
                                <td>
                                    <form action="<?php echo e(route('process-steps.destroy', $step)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-danger" onclick="return confirm('Delete this?')">Delete</button>
                                    </form>
                                    <!-- Optionally: Edit Btn/Modal Here -->
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dhard\Documents\Ompa27-WP_Monkey-laravel\resources\views/backend/layouts/process_steps/index.blade.php ENDPATH**/ ?>