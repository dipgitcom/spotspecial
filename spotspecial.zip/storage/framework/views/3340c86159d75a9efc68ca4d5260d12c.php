
<?php $__env->startSection('title', 'FAQ Management'); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row">
        <!-- FAQ Section Title/Subtitle -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5>FAQ Section Title & Subtitle</h5>
                </div>
                <div class="card-body">
                    <?php if(session('section_success')): ?>
                        <div class="alert alert-success"><?php echo e(session('section_success')); ?></div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('faq-section.update')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-2">
                            <label class="form-label">Title</label>
                            <input name="title" value="<?php echo e($section->title ?? ''); ?>" class="form-control" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Subtitle</label>
                            <input name="subtitle" value="<?php echo e($section->subtitle ?? ''); ?>" class="form-control">
                        </div>
                        <button class="btn btn-success w-100">Update Section</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- ADD FAQ FORM -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5>Add FAQ</h5>
                </div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('faqs.store')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-2">
                            <label class="form-label">Question</label>
                            <input name="question" class="form-control" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Answer</label>
                            <textarea name="answer" class="form-control" required></textarea>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Order</label>
                            <input type="number" name="order" class="form-control" value="1" required>
                        </div>
                        <button type="submit" class="btn btn-success w-100">Add FAQ</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- FAQ List -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5>All FAQs</h5>
                </div>
                <div class="card-body p-0">
                    <table class="table mb-0">
                        <thead><tr>
                            <th>Question</th><th>Answer</th><th>Order</th><th>Actions</th>
                        </tr></thead>
                        <tbody>
                        <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($f->question); ?></td>
                                <td><?php echo e($f->answer); ?></td>
                                <td><?php echo e($f->order); ?></td>
                                <td>
                                    <form method="POST" action="<?php echo e(route('faqs.destroy', $f)); ?>" style="display:inline-block">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-danger" onclick="return confirm('Delete?')">Delete</button>
                                    </form>
                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dhard\Documents\Ompa27-WP_Monkey-laravel\resources\views/backend/layouts/faqs/index.blade.php ENDPATH**/ ?>