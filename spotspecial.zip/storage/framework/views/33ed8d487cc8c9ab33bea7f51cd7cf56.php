<style>
    .card-custom {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        box-shadow: 0 4px 8px rgb(0 0 0 / 0.05);
        transition: box-shadow 0.3s ease;
    }

    .card-custom:hover {
        box-shadow: 0 8px 20px rgb(0 0 0 / 0.12);
    }

    #digitalClock {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        font-weight: 700;
        font-size: 1.5rem;
        color: #2563eb;
        /* blue-600 */
        user-select: none;
        min-width: 100px;
        text-align: center;
    }

    .welcome-text {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        font-weight: 600;
        color: #475569;
        /* slate-600 */
        margin-bottom: 0;
    }

    .icon-circle {
        width: 56px;
        height: 56px;
        background: #e0e7ff;
        /* light indigo */
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: inset 0 0 6px #c7d2fe;
    }

    .username {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        font-weight: 600;
        font-size: 1.1rem;
        color: #1e293b;
        /* slate-900 */
        margin-left: 16px;
    }
</style>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <div class="row  ">

            <div class="col-xl-4 col-lg-4 mb-5">
                <div class="card h-100 rounded-3 shadow-sm card-custom">
                    <div class="card-body p-4 d-flex flex-column align-items-center">

                        <!-- Top row: Clock and Welcome message -->
                        <div class="d-flex justify-content-center align-items-center gap-3 mb-4 w-100">
                            <!-- Digital Clock -->
                            <div id="digitalClock">--:--:--</div>

                            <!-- Welcome Text -->
                            <h5 class="welcome-text">Welcome To Dashboard</h5>
                        </div>

                        <!-- Bottom row: Icon and Username -->
                        <div class="d-flex align-items-center gap-3">
                            <div class="icon-circle">
                                <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="none"
                                    stroke="#3b82f6" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"
                                    class="feather feather-smile">
                                    <circle cx="14" cy="14" r="13"></circle>
                                    <path d="M9 20s3.5 3.5 10.5 0"></path>
                                    <line x1="10" y1="13" x2="10.01" y2="13"></line>
                                    <line x1="18" y1="13" x2="18.01" y2="13"></line>
                                </svg>
                            </div>

                            <span class="username"><?php echo e(Auth::user()->name); ?></span>
                        </div>

                    </div>
                </div>
            </div>

            <div class="col-xl-4 col-lg-4 mb-5">
                <div class="card h-100 card-lift">
                    <div class="card-body">
                        <!-- Title and Icon -->
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <span class="text-muted fw-semi-bold">Orders Summary</span>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" class="feather feather-shopping-bag text-primary">
                                    <path d="M6 2l1.5 4h9L18 2"></path>
                                    <path d="M3 6h18v14H3z"></path>
                                </svg>
                            </span>
                        </div>

                        <!-- Summary Grid -->
                        <div class="row g-3">
                            <!-- Today Orders -->
                            <div class="col-6">
                                <div
                                    class="border rounded p-2 h-100 d-flex flex-column justify-content-between text-center">
                                    <div class="fw-bold fs-4 text-info"></div>
                                    <div class="d-flex align-items-center justify-content-center mt-2">
                                        <svg class="text-info me-1" xmlns="http://www.w3.org/2000/svg" width="16"
                                            height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                            stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                            class="feather feather-calendar">
                                            <rect x="3" y="4" width="18" height="18" rx="2" ry="2">
                                            </rect>
                                            <line x1="16" y1="2" x2="16" y2="6"></line>
                                            <line x1="8" y1="2" x2="8" y2="6"></line>
                                            <line x1="3" y1="10" x2="21" y2="10"></line>
                                        </svg>
                                        <span class="fw-semibold text-info small">Today Orders</span>
                                    </div>
                                </div>
                            </div>

                            <!-- Previous Orders -->
                            <div class="col-6">
                                <div
                                    class="border rounded p-2 h-100 d-flex flex-column justify-content-between text-center">
                                    <div class="fw-bold fs-4 text-secondary"></div>
                                    <div class="d-flex align-items-center justify-content-center mt-2">
                                        <svg class="text-secondary me-1" xmlns="http://www.w3.org/2000/svg" width="16"
                                            height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                            stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                            class="feather feather-clock">
                                            <circle cx="12" cy="12" r="10"></circle>
                                            <polyline points="12 6 12 12 16 14"></polyline>
                                        </svg>
                                        <span class="fw-semibold text-secondary small">Previous Orders</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-4 col-lg-4 mb-5">
                <div class="card h-100 card-lift">
                    <div class="card-body">
                        <!-- Title and Card Icon -->
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <span class="text-muted fw-semi-bold">Monthly Summary</span>
                            <span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                    viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                    stroke-linecap="round" stroke-linejoin="round"
                                    class="feather feather-bar-chart-2 text-primary">
                                    <line x1="18" y1="20" x2="18" y2="10"></line>
                                    <line x1="12" y1="20" x2="12" y2="4"></line>
                                    <line x1="6" y1="20" x2="6" y2="14"></line>
                                </svg>
                            </span>
                        </div>

                        <!-- 3 Horizontal Cards -->
                        <div class="row g-3">
                            <!-- Completed -->
                            <div class="col-4">
                                <div
                                    class="border rounded p-2 h-100 d-flex flex-column justify-content-between text-center">
                                    <div class="fw-bold fs-4 text-success"></div>
                                    <div class="d-flex align-items-center justify-content-center mt-2">
                                        <svg class="text-success me-1" xmlns="http://www.w3.org/2000/svg" width="16"
                                            height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                            stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                            class="feather feather-check-circle">
                                            <path d="M9 12l2 2l4 -4"></path>
                                            <circle cx="12" cy="12" r="10"></circle>
                                        </svg>
                                        <span class="fw-semibold text-success small">Completed</span>
                                    </div>
                                </div>
                            </div>

                            <!-- Canceled -->
                            <div class="col-4">
                                <div
                                    class="border rounded p-2 h-100 d-flex flex-column justify-content-between text-center">
                                    <div class="fw-bold fs-4 text-danger"></div>
                                    <div class="d-flex align-items-center justify-content-center mt-2">
                                        <svg class="text-danger me-1" xmlns="http://www.w3.org/2000/svg" width="16"
                                            height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                            stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                            class="feather feather-x-circle">
                                            <circle cx="12" cy="12" r="10"></circle>
                                            <line x1="15" y1="9" x2="9" y2="15"></line>
                                            <line x1="9" y1="9" x2="15" y2="15"></line>
                                        </svg>
                                        <span class="fw-semibold text-danger small">Canceled</span>
                                    </div>
                                </div>
                            </div>

                            <!-- Pending -->
                            <div class="col-4">
                                <div
                                    class="border rounded p-2 h-100 d-flex flex-column justify-content-between text-center">
                                    <div class="fw-bold fs-4 text-warning"></div>
                                    <div class="d-flex align-items-center justify-content-center mt-2">
                                        <svg class="text-warning me-1" xmlns="http://www.w3.org/2000/svg" width="16"
                                            height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                            stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                            class="feather feather-clock">
                                            <circle cx="12" cy="12" r="10"></circle>
                                            <polyline points="12 6 12 12 16 14"></polyline>
                                        </svg>
                                        <span class="fw-semibold text-warning small">Pending</span>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
            </div>

        </div>


        <div class="row ">
            
            
            
        </div>

        <div class="row">
            
            

                        
                        

            
            

                        
                        
                    
<div class="row">
    <div class="col-md-6">
        
        <div class="card shadow-sm rounded mb-3">
            <div class="card-header border-0 pb-0 d-flex justify-content-between align-items-center" style="background: #5a4fdc;">
                <span class="text-white fw-bold fs-5">Total Posts</span>
                <span class="badge bg-white text-dark fs-6"><?php echo e($postCount); ?></span>
            </div>
            <div class="card-body pb-2 pt-3" style="background: #5a4fdc;">
                <?php if($userPosts->isEmpty()): ?>
                    <span class="text-white-50">No posts available.</span>
                <?php else: ?>
                    <?php $__currentLoopData = $userPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="text-white border-bottom border-white-25 py-1"><?php echo e($post->title); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        
        <div class="card shadow-sm rounded mb-3" style="background: #00b7e4;">
            <div class="card-header border-0 pb-0 d-flex justify-content-between align-items-center" style="background: #00b7e4;">
                <span class="text-white fw-bold fs-5">Total Trucks</span>
                <span class="badge bg-white text-dark fs-6"><?php echo e($truckCount); ?></span>
            </div>
            <div class="card-body pb-2 pt-3" style="background: #00b7e4;">
                <?php if($truckManages->isEmpty()): ?>
                    <span class="text-white-50">No trucks available.</span>
                <?php else: ?>
                    <?php $__currentLoopData = $truckManages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $truck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="text-white border-bottom border-white-25 py-1"><?php echo e($truck->name); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


            
            

                        
                        

        <div class="row">
            
        </div>




    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $.ajax({
                url: '/dashboard-data',
                method: 'GET',
                dataType: 'json',
                success: function(data) {
                    const monthlyData = data.monthlyComparisons;
                    if (!monthlyData) {
                        console.error('monthlyComparisons is missing from the response');
                        return;
                    }
                    // Extract data
                    const labels = monthlyData.map(item => item.month);
                    const completed = monthlyData.map(item => item.completed);
                    const cancelled = monthlyData.map(item => item.cancelled);
                    const pending = monthlyData.map(item => item.pending);

                    // Chart.js setup
                    const ctx = document.getElementById('monthlyComparisonCanvas').getContext('2d');
                    const monthlyChart = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: labels,
                            datasets: [{
                                    label: 'Completed',
                                    data: completed,
                                    backgroundColor: 'rgba(54, 162, 235, 0.7)' // Blue
                                },
                                {
                                    label: 'Cancelled',
                                    data: cancelled,
                                    backgroundColor: 'rgba(255, 99, 132, 0.7)' // Red
                                },
                                {
                                    label: 'Pending',
                                    data: pending,
                                    backgroundColor: 'rgba(255, 206, 86, 0.7)' // Yellow
                                }
                            ]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    ticks: {
                                        stepSize: 1
                                    }
                                }
                            }
                        }
                    });
                },
                error: function(xhr, status, error) {
                    console.error('AJAX error:', error);
                }
            });
        });
    </script>

    </script>
    <script>
        function updateClock() {
            const clock = document.getElementById('digitalClock');
            if (!clock) return;
            const now = new Date();
            const hours = String(now.getHours()).padStart(2, '0');
            const mins = String(now.getMinutes()).padStart(2, '0');
            const secs = String(now.getSeconds()).padStart(2, '0');
            clock.textContent = `${hours}:${mins}:${secs}`;
        }
        setInterval(updateClock, 1000);
        updateClock(); // initial call
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/dipraj-dhar/Downloads/Telegram Desktop/screnzo/resources/views/backend/layouts/dashboard.blade.php ENDPATH**/ ?>