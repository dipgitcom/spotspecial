<?php $__env->startPush('styles'); ?>
<link href="https://cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet" />
<style>
    #reportDetailsCard { transition: all 0.3s; }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title', 'User Reports'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Reports Table -->
    <div class="col-lg-7">
        <div class="card mb-4">
            <div class="card shadow-sm mb-2">
                        <div class="card-header text-white text-center ">
                            <h3 class="mb-0">
                                User Reports
                            </h3>
                        </div>
                    </div>
            <div class="card-body">
                <table id="reportsTable" class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Reporter</th>
                            <th>Rep.User</th>
                            <th>Count</th>
                            <th>Reason</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>View</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Report Details / Update -->
    <div class="col-lg-5">
        <div id="reportDetailsCard" class="d-none">
            <div class="card shadow-sm">
                <div class="card-header ">
                    <h5 id="detailsTitle">Report Details</h5>
                </div>
                <div class="card-body" id="detailsBody">
                    <!-- AJAX-loaded details will appear here -->
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function() {
    const table = $('#reportsTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: '<?php echo e(route("layouts.reports.data")); ?>',
        columns: [
            { data: 'DT_RowIndex', orderable: false, searchable: false },
           { data: 'reporter_name', name: 'reporter_name' },
           { data: 'reported_user_name', name: 'reported_user_name' },
            { data: 'report_count', orderable: false, searchable: false },
            { data: 'reason_text' },
            { data: 'report_status', orderable: false, searchable: false, render: function(data, type, row) {
                return `<select class="form-select update-status" data-id="${row.id}">
                    <option value="pending" ${data==='pending'?'selected':''}>Pending</option>
                    <option value="reviewed" ${data==='reviewed'?'selected':''}>Reviewed</option>
                    <option value="resolved" ${data==='resolved'?'selected':''}>Resolved</option>
                </select>`;
            }},
            { data: 'created_at' },
            { data: 'view_link', orderable: false, searchable: false },
            { data: 'admin_actions', orderable: false, searchable: false }
        ],
    });

    // Inline status update in table
    $('#reportsTable').on('change', '.update-status', function() {
        let id = $(this).data('id');
        let status = $(this).val();
        $.post(`/reports/${id}/update`, {_token:'<?php echo e(csrf_token()); ?>', report_status: status}, function(res){
            Swal.fire('Success', res.message, 'success');
            table.ajax.reload(null,false);
        }).fail(function(xhr){
            Swal.fire('Error', xhr.responseJSON?.message || 'Update failed','error');
        });
    });

    // Load details in the right card
    $('#reportsTable').on('click', '.btn-view-report', function() {
        let id = $(this).data('id');
        $.get(`/reports/${id}`, function(data){
            let html = `
                <div class="mb-3"><strong>Reporter:</strong> ${data.reporter?.name || 'N/A'}</div>
                <div class="mb-3"><strong>Reported User:</strong> ${data.reportedUser?.name || 'N/A'}</div>
                <div class="mb-3"><strong>Reason:</strong> ${data.report_reason || 'N/A'}</div>
                <div class="mb-3">
                    <strong>Status:</strong>
                    <form id="report-status-form">
                        <?php echo csrf_field(); ?>
                        <select name="report_status" class="form-select">
                            <option value="pending" ${data.report_status==='pending'?'selected':''}>Pending</option>
                            <option value="reviewed" ${data.report_status==='reviewed'?'selected':''}>Reviewed</option>
                            <option value="resolved" ${data.report_status==='resolved'?'selected':''}>Resolved</option>
                        </select>
                        <button type="submit" class="btn btn-success btn-sm mt-2">Update Status</button>
                    </form>
                </div>
                <div class="mb-3"><strong>Reported On:</strong> ${data.created_at}</div>
            `;
            $('#detailsBody').html(html);
            $('#reportDetailsCard').removeClass('d-none');

            // Bind inline update inside details card
            $('#report-status-form').off('submit').on('submit', function(e){
                e.preventDefault();
                $.post(`/reports/${id}/update`, $(this).serialize(), function(res){
                    Swal.fire('Success', res.message, 'success');
                    table.ajax.reload(null,false);
                }).fail(function(xhr){
                    Swal.fire('Error', xhr.responseJSON?.message || 'Update failed','error');
                });
            });
        });
    });

    // Admin actions (Warn/Block/Disable)
    $('#reportsTable').on('click', '.action-btn', function(e){
        e.preventDefault();
        let form = $(this).closest('form');
        let action = $(this).data('action');
        Swal.fire({
            title:`Confirm ${action}`,
            text:`Are you sure you want to ${action.toLowerCase()} this user?`,
            icon:'warning',
            showCancelButton:true,
            confirmButtonText:action,
            cancelButtonText:'Cancel'
        }).then(result=>{
            if(result.isConfirmed){
                $.post(form.attr('action'), form.serialize(), function(res){
                    Swal.fire('Success', res.message || `${action} completed`, 'success');
                    table.ajax.reload(null,false);
                }).fail(function(xhr){
                    Swal.fire('Error', xhr.responseJSON?.message || 'Action failed','error');
                });
            }
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dhard\Documents\ompa27\resources\views/backend/layouts/reports/index.blade.php ENDPATH**/ ?>