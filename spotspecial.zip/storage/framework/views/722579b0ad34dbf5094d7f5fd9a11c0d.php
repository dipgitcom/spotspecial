<?php $__env->startPush('styles'); ?>
<link href="https://cdn.jsdelivr.net/npm/summernote@0.8.20/dist/summernote-lite.min.css" rel="stylesheet" />
<link href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title', 'Report Reasons'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow-sm mb-2">
                        <div class="card-header text-white text-center ">
                            <h3 class="mb-0">
                                Report Reasons
                            </h3>
                        </div>
                    </div>
<div class="row">
    <!-- Reasons List -->
    <div class="col-lg-7">
        <div class="card">
            <div class="card-header">
                <label class="form-label">Report Reasons List</label>
            </div>
            <div class="card-body">
                <table id="reasonsTable" class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Reason</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Create Form -->
    <div class="col-lg-5">
        <div id="createReasonForm">
            <form id="addReasonForm">
                <?php echo csrf_field(); ?>
                <div class="card shadow-sm mb-2">
                    <div class="card-header text-white text-center ">
                        <h5>
                        <i class="bi bi-plus-circle me-2"></i>Add New Reason
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Reason</label>
                            <input type="text" name="reason" class="form-control" required />
                        </div>
                        <button type="submit" class="btn btn-success w-100">Create</button>
                    </div>
                </div>
            </form>
        </div>

        <!-- Edit Form -->
        <div id="editReasonForm" class="d-none">
            <form id="editReasonFormElement" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="card shadow-sm mb-2">
                    <div class="card-header text-white text-center bg-warning">
                        <h5 class="mb-0">
                        <i class="bi bi-pencil-square me-2"></i>Edit Reason
                        </h5>
                    </div>
                    <div class="card-body">
                        <input type="hidden" name="reason_id" id="reason_id" />
                        <div class="mb-3">
                            <label class="form-label">Reason</label>
                            <input type="text" name="reason" id="edit_reason" class="form-control" required />
                        </div>
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary w-100">Update</button>
                            <button type="button" class="btn btn-secondary w-100" id="cancelEdit">Cancel</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap5.min.js"></script>

<script>
$(function() {
    const table = $('#reasonsTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: "<?php echo e(route('report_reason.list')); ?>",
        columns: [
            { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
            { data: 'reason', name: 'reason' },
            { data: 'action', name: 'action', orderable: false, searchable: false }
        ],
    });

    // Show edit form on edit button click
    $(document).on('click', '.edit', function() {
        const id = $(this).data('id');
        $.get(`/report_reason/${id}/edit`, function(data) {
            $('#createReasonForm').hide();
            $('#editReasonForm').removeClass('d-none').show();
            $('#reason_id').val(data.data.id);
            $('#edit_reason').val(data.data.reason);
        });
    });

    // Cancel edit form
    $('#cancelEdit').click(function() {
        $('#editReasonForm').hide();
        $('#createReasonForm').show();
    });

    // Submit create form
    $('#addReasonForm').submit(function(e) {
        e.preventDefault();
        $.post("<?php echo e(route('report_reason.store')); ?>", $(this).serialize())
            .done(function(data) {
                Swal.fire('Success', data.success, 'success');
                table.ajax.reload();
                $('#addReasonForm')[0].reset();
            })
            .fail(function(response) {
                Swal.fire('Error', response.responseJSON.message || 'Failed to add reason', 'error');
            });
    });

    // Submit edit form
    $('#editReasonFormElement').submit(function(e) {
        e.preventDefault();
        const id = $('#reason_id').val();
        $.ajax({
            url: `/report_reason/${id}`,
            method: 'PUT',
            data: $(this).serialize(),
            success: function(data) {
                Swal.fire('Success', data.success, 'success');
                table.ajax.reload();
                $('#editReasonForm').hide();
                $('#createReasonForm').show();
            },
            error: function(xhr) {
                Swal.fire('Error', xhr.responseJSON.message || 'Failed to update reason', 'error');
            }
        });
    });

    // Delete reason
    $('#reasonsTable tbody').on('click', '.delete', function() {
        const id = $(this).data('id');
        Swal.fire({
            title: 'Are you sure?',
            text: "This action is irreversible!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'Cancel'
        }).then(result => {
            if (result.isConfirmed) {
                $.ajax({
                    url: `/report_reason/${id}`,
                    type: 'DELETE',
                    data: { _token: '<?php echo e(csrf_token()); ?>' },
                    success: function(data) {
                        Swal.fire('Deleted!', data.success, 'success');
                        table.ajax.reload();
                    },
                    error: function() {
                        Swal.fire('Error!', 'Failed to delete reason.', 'error');
                    }
                });
            }
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dhard\Documents\ompa27\resources\views/backend/layouts/reports/report_reason/index.blade.php ENDPATH**/ ?>