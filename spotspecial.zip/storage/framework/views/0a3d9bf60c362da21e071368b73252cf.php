<!-- navbar vertical -->
<div class="app-menu">
    <div class="navbar-vertical navbar nav-dashboard">
        <div class="h-100" data-simplebar>
            <!-- Brand logo -->
            <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">
                <img
                    src="<?php echo e(isset($admin_setting->logo) ? asset($admin_setting->logo) : asset('uploads/default.png')); ?>" />
            </a>
            <!-- Navbar nav -->
            <ul class="navbar-nav flex-column" id="sideNavbar">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                        <i data-feather="bar-chart-2" class="nav-icon me-2 icon-xxs"></i>
                        Dashboard
                    </a>
                </li>




                



                <li class="nav-title" 





                




                <!-- Section title centered and bold -->
                <li class="nav-title"
                    style="font-weight:700; letter-spacing:2px; font-size:10x; color:#222; background:#f8f9fa; border-radius:6px; margin:11px 0; padding:7px 0; text-align:center;">
                    Site Section Management
                </li>
                

                <li class="nav-item <?php echo e(request()->routeIs('admin.hero-section.*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.hero-section.edit')); ?>">
                        <i data-feather="zap" class="nav-icon me-2 icon-xxs"></i>
                        Hero Section
                    </a>
                </li>


                <li class="nav-item <?php echo e(request()->routeIs('admin.navbar.*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.navbar.index')); ?>">
                        <i data-feather="sliders" class="nav-icon me-2 icon-xxs"></i>
                        Navbar Management
                    </a>
                </li>

                <li class="nav-item <?php echo e(request()->routeIs('admin.service-packages.*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.service-packages.index')); ?>">
                        <i data-feather="package" class="nav-icon me-2 icon-xxs"></i>
                        Service Packages
                    </a>
                </li>
                <li class="nav-item <?php echo e(request()->routeIs('why-us-panels.*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('why-us-panels.index')); ?>">
                        <i data-feather="star" class="nav-icon me-2 icon-xxs"></i>
                        Why Us Panels
                    </a>
                </li>

                <li class="nav-item <?php echo e(request()->routeIs('process-steps.*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('process-steps.index')); ?>">
                        <i data-feather="list" class="nav-icon me-2 icon-xxs"></i>
                        Process Steps
                    </a>
                </li>
                <li class="nav-item <?php echo e(request()->routeIs('galleries.*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('galleries.index')); ?>">
                        <i data-feather="image" class="nav-icon me-2 icon-xxs"></i>
                        Gallery
                    </a>
                </li>
                <li class="nav-item <?php echo e(request()->routeIs('testimonials.*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('testimonials.index')); ?>">
                        <i data-feather="message-circle" class="nav-icon me-2 icon-xxs"></i>
                        Testimonials
                    </a>
                </li>
                <li class="nav-item <?php echo e(request()->routeIs('faqs.*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('faqs.index')); ?>">
                        <i data-feather="help-circle" class="nav-icon me-2 icon-xxs"></i>
                        FAQs
                    </a>
                </li>

                <!-- Contact Dropdown in Sidebar -->
                <!-- Contact Section - Accordion/collapse style -->
                <li
                    class="nav-item <?php echo e(request()->routeIs('contact-section.*') || request()->routeIs('contact-submissions.*') ? 'active' : ''); ?>">
                    <a class="nav-link has-arrow" data-bs-toggle="collapse" data-bs-target="#contactSectionCollapse"
                        aria-expanded="<?php echo e(request()->routeIs('contact-section.*') || request()->routeIs('contact-submissions.*') ? 'true' : 'false'); ?>"
                        aria-controls="contactSectionCollapse">
                        <i data-feather="mail" class="nav-icon me-2 icon-xxs"></i>
                        Contact
                    </a>
                    <div id="contactSectionCollapse"
                        class="collapse <?php echo e(request()->routeIs('contact-section.*') || request()->routeIs('contact-submissions.*') ? 'show' : ''); ?>"
                        data-bs-parent="#sideNavbar">
                        <ul class="nav flex-column ms-3">
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('contact-section.*') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('contact-section.edit')); ?>">
                                    <i data-feather="settings" class="nav-icon me-2 icon-xxs"></i>
                                    Section Settings
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('contact-submissions.*') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('contact-submissions.index')); ?>">
                                    <i data-feather="database" class="nav-icon me-2 icon-xxs"></i>
                                    Data
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="nav-item <?php echo e(request()->routeIs('footer-settings.*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('footer-settings.edit')); ?>">
                        <i data-feather="slash" class="nav-icon me-2 icon-xxs"></i>
                        Footer Settings
                    </a>
                </li>


                



                <!-- Sidebar report structure -->

                

                










                <li class="nav-title"
                    style="font-weight:700; letter-spacing:2px; font-size:10x; color:#222; background:#f8f9fa; border-radius:6px; margin:11px 0; padding:7px 0; text-align:center;">
                    System Content Management
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('dynamic-pages.index')); ?>">
                        <i class="bi bi-file-earmark-text fs-4 me-2"></i>
                        Dynamic Pages
                    </a>
                </li>

                


















                
                <li class="nav-item <?php echo e(request()->routeIs('user.*', 'role.*', 'permission.*') ? 'active' : ''); ?>">
                    <a class="nav-link has-arrow" data-bs-toggle="collapse" data-bs-target="#roleManagementCollapse"
                        aria-expanded="<?php echo e(request()->routeIs('users.*', 'roles.*', 'permissions.*') ? 'true' : 'false'); ?>"
                        aria-controls="roleManagementCollapse">
                        <i data-feather="shield" class="nav-icon me-2 icon-xxs"></i>
                        Role Management
                    </a>

                    <div id="roleManagementCollapse"
                        class="collapse <?php echo e(request()->routeIs('user.*', 'role.*', 'permission.*') ? 'show' : ''); ?>"
                        data-bs-parent="#sidebarMenu">

                        <ul class="nav flex-column ms-3">
                            
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('user.*') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('user.index')); ?>">
                                    Users
                                </a>
                            </li>

                            
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('role.*') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('role.index')); ?>">
                                    Roles
                                </a>
                            </li>

                            
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('permission.*') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('permission.index')); ?>">
                                    Permissions
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>




                
                <li class="nav-title"
                    style="font-weight:700; letter-spacing:2px; font-size:10x; color:#222; background:#f8f9fa; border-radius:6px; margin:11px 0; padding:7px 0; text-align:center;">
                    System Settings
                </li>
                <li
                    class="nav-item <?php echo e(request()->routeIs('profile.*', 'mail.*', 'system.*', 'admin.*') ? 'active' : ''); ?>">
                    <a class="nav-link has-arrow" href="" data-bs-toggle="collapse" data-bs-target="#settingsCollapse"
                        aria-expanded="<?php echo e(request()->routeIs('profile.*', 'mail.*', 'system.*', 'admin.*') ? 'true' : 'false'); ?>"
                        aria-controls="settingsCollapse">
                        <i data-feather="settings" class="nav-icon me-2 icon-xxs"></i>Settings
                    </a>

                    <div id="settingsCollapse"
                        class="collapse <?php echo e(request()->routeIs('profile.*', 'mail.*', 'system.*', 'admin.*') ? 'show' : ''); ?>"
                        data-bs-parent="#sidebarMenu">
                        <ul class="nav flex-column ms-3">
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('profile.index') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('profile.index')); ?>">
                                    Profile Setting
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('admin.setting.index') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('admin.setting.index')); ?>">
                                    Admin Setting
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('mail.index') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('mail.index')); ?>">
                                    Mail Setting
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                
                
            </ul>

        </div>
    </div>
</div><?php /**PATH C:\Users\dhard\Documents\Ompa27-WP_Monkey-laravel\resources\views/backend/partials/sidebar.blade.php ENDPATH**/ ?>