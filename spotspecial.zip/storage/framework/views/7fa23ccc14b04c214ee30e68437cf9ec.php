<?php $__env->startSection('title', 'Chatting with Users'); ?>

<?php $__env->startPush('styles'); ?>
    <style>

        .chat-container {
            display: flex;
            flex-direction: row;
            height: 600px;
            border: 1px solid #ccc;
            border-radius: 10px;
            overflow: hidden;
            width: 80%;
        }

        /* Sidebar (Left Panel) */
        .chat-list {
            width: 30%;
            background: #032b44;
            color: #fff;
            overflow-y: auto;
        }

        .chat-list div {
            padding: 15px;
            border-bottom: 1px solid #333;
            cursor: pointer;
        }

        .chat-list div:hover {
            background: #444;
        }

        .chat-list div.active {
            background: #444 !important;
        }

        /* Conversation (Right Panel) */
        .chat-window {
            width: 70%;
            display: flex;
            flex-direction: column;
            background: bisque;
        }

        .chat-messages {
            flex: 1;
            padding: 15px;
            overflow-y: auto;
        }

        /* Message bubbles */
        .message {
            margin-bottom: 12px;
            padding: 10px 15px;
            border-radius: 18px;
            max-width: 60%;
            clear: both;
            font-size: 14px;
            line-height: 1.4;
            word-wrap: break-word;
            position: relative;
        }

        .message.user {
            background: #f1f1f1;
            color: #000;
            float: left;
        }

        .message.admin {
            background: #dcf8c6;
            color: #000;
            float: right;
        }

        .message .sender-info {
            font-size: 11px;
            color: #555;
            margin-bottom: 4px;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .message .sender-info img {
            width: 18px;
            height: 18px;
            border-radius: 50%;
        }

        /* Input box */
        .chat-input {
            border-top: 1px solid #ddd;
            padding: 10px;
            display: flex;
            background: #fff;
        }

        .chat-input input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 20px;
            margin-right: 10px;
        }

        .chat-input button {
            border-radius: 20px;
            padding: 0 20px;
        }

        /* Unread count badge */
        .unread-badge {
            background: #44bd61;
            color: #fff;
            font-size: 12px;
            font-weight: bold;
            border-radius: 50%;
            padding: 4px 8px;
            min-width: 22px;
            text-align: center;
            display: inline-block;
        }

        /* 🔹 Mobile Responsive */
        @media (max-width: 768px) {
            .chat-container {
                flex-direction: column;
                height: auto;
            }

            .chat-list {
                width: 100%;
                max-height: 200px;
                border-bottom: 1px solid #333;
            }

            .chat-window {
                width: 100%;
                height: calc(100vh - 200px);
            }

            .chat-messages {
                padding: 10px;
                font-size: 13px;
            }

            .message {
                max-width: 80%;
                font-size: 13px;
            }

            .chat-input input {
                font-size: 14px;
            }
        }

        /* File Preview Container */
        #filePreview img {
            max-width: 50px;
            max-height: 50px;
            border-radius: 6px;
            margin-right: 8px;
            border: 1px solid #ccc;
        }

        #filePreview span {
            font-size: 13px;
            color: #555;
            margin-right: 8px;
        }

        /* Fullscreen Image Modal */
        #imageModal {
            display: none;
            position: fixed;
            z-index: 9999;
            padding-top: 50px;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.8);
        }

        #imageModal img {
            margin: auto;
            display: block;
            max-width: 90%;
            max-height: 80vh;
            border-radius: 8px;
        }

        #imageModal span {
            position: absolute;
            top: 20px;
            right: 35px;
            color: #fff;
            font-size: 40px;
            font-weight: bold;
            cursor: pointer;
        }

        /* Next & Prev buttons */
        #imageModal .prev,
        #imageModal .next {
            cursor: pointer;
            position: absolute;
            top: 50%;
            width: auto;
            padding: 16px;
            margin-top: -22px;
            color: #fff;
            font-weight: bold;
            font-size: 30px;
            border-radius: 3px;
            user-select: none;
        }

        #imageModal .prev {
            left: 20px;
        }

        #imageModal .next {
            right: 20px;
        }

        #imageModal .prev:hover,
        #imageModal .next:hover {
            background-color: rgba(0, 0, 0, 0.5);
        }

        /* loader  */
        .pdf-download {
            display: flex;
            align-items: center;
            gap: 6px;
            cursor: pointer;
            font-size: 14px;
            color: #007bff;
            transition: 0.3s;
        }

        .pdf-download:hover {
            color: #0056b3;
        }

        .pdf-status {
            font-size: 12px;
            color: #555;
        }

        .loader {
            border: 2px solid #f3f3f3;
            border-top: 2px solid #007bff;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            animation: spin 1s linear infinite;
            display: inline-block;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }


        /* smoother downloader */
        .file-download {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 12px;
            border-radius: 12px; /* smoother corners */
            background-color: #f7f7f7;
            cursor: pointer;
            transition: all 0.2s ease-in-out;
            box-shadow: 0 2px 4px rgba(0,0,0,0.08);
        }

        .file-download:hover {
            background-color: #e6f0ff; /* subtle highlight on hover */
            transform: translateY(-2px); /* slight lift */
            box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }

        .file-download:active {
            transform: translateY(0); /* reset on click */
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .file-icon img {
            border-radius: 6px;
            transition: transform 0.2s ease-in-out;
        }

        .file-download:hover .file-icon img {
            transform: scale(1.1); /* slight zoom effect on icon */
        }

        .file-name {
            font-size: 14px;
            color: #333;
            font-weight: 500;
        }

        .file-status {
            font-size: 12px;
            color: #555;
        }

        /* pdf modal */
        .pdf-modal {
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.6);
            display: none;
            align-items: center;
            justify-content: center;
        }

        .modal-content {
            background: #fff;
            border-radius: 12px;
            width: 95%;
            max-width: 1200px;
            height: 85%;
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
            position: relative;
            overflow: hidden;
        }

        .modal-content iframe {
            width: 100%;
            height: 100%;
            border: none;
        }

        .close {
            position: absolute;
            top: 12px;
            right: 10px;   /* moved a bit more right */
            font-size: 28px;
            font-weight: bold;
            color: #333;
            cursor: pointer;
            transition: color 0.2s;
            background: rgba(255,255,255,0.8);
            border-radius: 50%;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .close:hover {
            color: red;
            background: rgba(255,255,255,1);
        }

        /* header css */

        .chat-header {
            display: flex;
            align-items: center;
            padding: 10px 10px;   /* reduced padding */
            border-bottom: 1px solid #e0e0e0;
            background-color: #f9f9f9;
            position: sticky;
            top: 0;
            z-index: 10;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }

        .chat-header-img {
            width: 36px;    /* smaller profile pic */
            height: 36px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 10px;
            border: 2px solid #007bff;
        }

        .chat-header-name {
            font-weight: 600;
            font-size: 14px;   /* slightly smaller text */
            color: #333;
        }

        .chat-header-status {
            font-size: 12px;   /* smaller status */
            color: #777;
            margin-top: 2px;
        }


        /* Optional: add a small online dot on the image */
        .chat-header-img::after {
            content: '';
            position: absolute;
            width: 12px;
            height: 12px;
            background-color: #4caf50; /* green for online */
            border: 2px solid #fff;
            border-radius: 50%;
            bottom: 2px;
            right: 2px;
        }
        .hidden{
            display: none;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-header">
        <div>
            <h1 class="page-title">Chatting System</h1>
        </div>
    </div>
    <div id="pdfModal" class="pdf-modal" >
        <div class="modal-content">
            <span class="close" onclick="closePdfModal()">&times;</span>
            <iframe id="modalPdf" src="" frameborder="0"></iframe>
        </div>
    </div>

    <div class="">
        <div class="card-body">
            <div class="chat-container">
                <!-- Left: Chat List -->

                <div class="chat-list" id="chat-list">

                    Loading chats...
                </div>

                <!-- Right: Conversation -->
                <div class="chat-window">
                    <!-- Profile Header -->
                    <div class="chat-header hidden">
                        <div style="position: relative;">
                            <img src="" alt="Profile" class="chat-header-img">
                        </div>
                        <div class="chat-header-info">
                            <span class="chat-header-name">User Name</span>
                        </div>
                    </div>
                    <div class="chat-messages" id="conversation">
                        <p style="text-align:center; color:#777;">Select a conversation</p>
                    </div>

                    <!-- Image Preview Modal -->
                    <div id="imageModal">
                        <span class="close" onclick="closeModal()">&times;</span>
                        <img id="modalImage" src="">
                        <a class="prev" onclick="changeSlide(-1)">&#10094;</a>
                        <a class="next" onclick="changeSlide(1)">&#10095;</a>
                    </div>


                    <div class="chat-input">
                        <!-- Preview Container -->
                        <div id="filePreview" style="margin-right:10px;"></div>
                        <!-- 🔹 File Upload -->
                        <input type="file" id="replyFile" style="display:none;" accept="image/*,.pdf">

                        <!-- Upload Button -->
                        <button type="button" onclick="document.getElementById('replyFile').click()" class="btn btn-light"
                            style="margin-right:5px;">
                            +
                        </button>
                        <input type="text" id="replyMessage" placeholder="Type a message...">
                        <button onclick="sendReply()" class="btn btn-primary">Send</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        let currentConversationId = null;
        let currentReceiverId = null;
        let userScrolled = false;
        const $download_av = "<?php echo e(asset('frontend/download-icon.png')); ?>";
        const $pdf_av = "<?php echo e(asset('frontend/pdf-file.png')); ?>";
        const conversationDiv = document.getElementById("conversation");

        // Track user scroll
        conversationDiv.addEventListener("scroll", () => {
            if (conversationDiv.scrollTop + conversationDiv.clientHeight < conversationDiv.scrollHeight) {
                userScrolled = true;
            } else {
                userScrolled = false;
            }
        });
        function isImage(fileUrl) {
            return /\.(jpg|jpeg|png|gif|webp|svg)$/i.test(fileUrl);
        }
        async function loadChatList() {
            let res = await fetch("admin/api/chat/list", {
                headers: {
                    "Accept": "application/json"
                },
                credentials: "same-origin"
            });
            let data = await res.json();

            if (data.status) {
                let html = `
                `;
                // <div class="list-header">
                //         <div class="list-header-profile">
                //             <img src="" alt="Profile" class="list-header-img">
                //         </div>
                //         <div class="list-header-details">
                //             <span class="list-header-name">User Name</span>
                //             <span class="list-header-status">Active now</span>
                //         </div>
                //         <div class="list-header-actions">
                //             <button class="header-action-btn">⋮</button>
                //         </div>
                //     </div>
                data.data.forEach(chat => {
                    let isActive = (chat.conversation_id === currentConversationId) ? "active" : "";
                    html += `
            <div onclick="openConversation('${chat.conversation_id}', ${chat.receiver_id}, event, '${chat.user_image}', '${chat.user_name}')"
                 class="${isActive}">
                <div class="d-flex align-items-center">
                    <img src="${chat.user_image ? chat.user_image : '/frontend/default-avatar-profile.jpg'}"
                         alt="user-avatar" class="avatar rounded-circle me-1" width="30" height="30">
                    <span class="ms-1"><b>${chat.user_name ? chat.user_name : 'Anonymous'}</b></span>
                </div>
                <span class="unread-badge" style="float:right; margin-right:5px;">${chat.unread_count}</span>
                ${chat.message_type === "image" ? "<i>Sent a photo</i>" :
                    (chat.message.length > 20 ? `${chat.message.substring(0, 20)}...` : chat.message)}
            </div>
            `;
                });
                document.getElementById("chat-list").innerHTML = html;
            } else {
                document.getElementById("chat-list").innerHTML = "No chats found.";
            }
        }

        // Open conversation
        async function openConversation(conversationId, receiverId, event = null, sender_image, sender_name) {
            currentConversationId = conversationId;
            currentReceiverId = receiverId;

            let header = document.querySelector('.chat-header');
            let nameElement = document.querySelector('.chat-header-name');
            let imgElement = document.querySelector('.chat-header-img');
            header.classList.remove('hidden');

            // highlight active
            if (event) {
                document.querySelectorAll(".chat-list div").forEach(el => el.classList.remove("active"));
                event.currentTarget.classList.add("active");
            }

            let res = await fetch(`admin/api/chat/get/${conversationId}`, {
                headers: {
                    "Accept": "application/json"
                },
                credentials: "same-origin"
            });
            let data = await res.json();
            if (data.status) {
                let html = "";

                data.data.forEach(msg => {
                    html += `
            <div class="message ${msg.sender_id === currentReceiverId ? 'user' : 'admin'}">
                <div class="sender-info" style="display:flex;align-items:center;margin-bottom:4px;">
                    <img src="${msg.sender_user_image}" width="25" height="25" style="border-radius:50%;margin-right:5px;">
                    <span style="font-size:12px;color:#555;">${msg.sender_user_name}</span>
                </div>
                ${msg.message ? msg.message : ""}

                ${msg.image
                ? `<br>
                ${isImage(msg.image)
                        ? `<img class="modal-img" src="${msg.image}" width="120" style="border-radius:8px;cursor:pointer;" onclick="openModal('${msg.image}')">`
                        : msg.image.endsWith('.pdf')
                            ? `<div class="file-download" onclick="openPdfModal('${msg.image}')">
                                    <span class="file-icon">
                                        <img src="${$pdf_av}" width="24" alt="PDF">
                                    </span>
                                    <span class="file-name">${msg.image.split('/').pop()}</span>
                                </div>`
                            : `<div class="file-download" onclick="downloadFile('${msg.image}', this)">
                                    <span class="file-icon">
                                        <img src="${$download_av}" width="24" alt="Download">
                                    </span>
                                    <span class="file-name">${msg.image.split('/').pop()}</span>
                                    <span class="file-status"></span>
                            </div>`
                }`
                : ""}
            </div>
            `;
                imgElement.src = data.data[0]['sender_user_image'];
                nameElement.textContent = data.data[0]['sender_user_name'];
                });
                conversationDiv.innerHTML = html;

                if (!userScrolled) {
                    conversationDiv.scrollTop = conversationDiv.scrollHeight;
                }
            }

            // Mark messages as read
            await fetch(`admin/api/chat/mark/read/${conversationId}`, {
                method: "GET",
                headers: {
                    "Accept": "application/json"
                },
                credentials: "same-origin"
            });
        }

        // File preview when selected
        document.getElementById("replyFile").addEventListener("change", function(e) {
            const previewDiv = document.getElementById("filePreview");
            previewDiv.innerHTML = "";

            const file = e.target.files[0];
            if (!file) return;

            if (file.type.startsWith("image/")) {
                const img = document.createElement("img");
                img.src = URL.createObjectURL(file);
                previewDiv.appendChild(img);
            } else {
                const span = document.createElement("span");
                span.textContent = file.name;
                previewDiv.appendChild(span);
            }
        });
        document.getElementById("replyMessage").addEventListener("keydown", function (event) {
            if (event.key === "Enter" && !event.shiftKey) { 
                event.preventDefault(); // prevent newline
                sendReply();
            }
        });
        // Send reply
        async function sendReply() {
            if (!currentReceiverId) return toastr.warning("Please select a conversation first");

            let message = document.getElementById("replyMessage").value;
            let file = document.getElementById("replyFile").files[0];

            if (!message && !file) {
                return toastr.error("Please type a message or select a file");
            }

            let formData = new FormData();
            formData.append("receiver_id", currentReceiverId);
            formData.append("message", message);

            if (file) {
                formData.append("image", file);
            }

            let res = await fetch("admin/api/chat/send", {
                method: "POST",
                body: formData,
                credentials: "same-origin"
            });

            let data = await res.json();
            if (data.status) {
                document.getElementById("replyMessage").value = "";
                document.getElementById("replyFile").value = "";
                document.getElementById("filePreview").innerHTML = "";
                userScrolled = false;

                openConversation(currentConversationId, currentReceiverId);
                loadChatList();
            } else {
                toastr.success(data.message);
            }
        }

        let imageList = []; // List of images
        let currentIndex = 0; // Current index of the image being shown

        // Image Modal Functions
        // Toggle image modal visibility
        function openModal(src) {
            modalImages = Array.from(document.querySelectorAll(".chat-messages img.modal-img"))
                .map(img => img.getAttribute('src')); // Map image src to an array of image sources
            currentIndex = modalImages.indexOf(src); // Set current index to the index of the src in the modal images array

            document.getElementById("imageModal").style.display = "block";
            document.getElementById("modalImage").src = src;
        }
        function downloadFile(fileUrl, element) {
            const iconEl = element.querySelector(".file-icon");
            const statusEl = element.querySelector(".file-status");

            // Show loader
            iconEl.innerHTML = '<div class="loader"></div>';
            statusEl.textContent = "Downloading...";

            fetch(fileUrl)
                .then(response => response.blob())
                .then(blob => {
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement("a");
                    a.href = url;
                    a.download = fileUrl.split('/').pop();
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    window.URL.revokeObjectURL(url);

                    // Show file icon (e.g. PDF/ZIP/Generic)
                    iconEl.innerHTML = `<img src="${$pdf_av}" width="24" alt="File">`;
                    statusEl.textContent = "Downloaded";

                    setTimeout(() => {
                        iconEl.innerHTML = `<img src="${$download_av}" width="24" alt="Download">`;
                        statusEl.textContent = "";
                    }, 5000);
                })
                .catch((e) => {
                    // console.log(e)
                    statusEl.textContent = "❌ Failed";
                    statusEl.style.color = "red";
                });
        }


        // Modal close
        function closeModal() {
            document.getElementById("imageModal").style.display = "none";
            document.getElementById("modalImage").src = "";
            modalImages = [];
            currentIndex = 0;
        }

        function openPdfModal(fileUrl) {
            const modal = document.getElementById('pdfModal');
            const iframe = document.getElementById('modalPdf');
            iframe.src = fileUrl;
            modal.style.display = 'flex'; // FLEX to keep centering
        }

        function closePdfModal() {
            const modal = document.getElementById('pdfModal');
            modal.style.display = 'none';
        }
        // Next/Prev
        function changeSlide(step) {
            if (modalImages.length === 0) return;

            currentIndex += step;

            if (currentIndex < 0) currentIndex = modalImages.length - 1;
            if (currentIndex >= modalImages.length) currentIndex = 0;

            document.getElementById("modalImage").src = modalImages[currentIndex];
        }
        loadChatList();

        setInterval(() => {
            loadChatList();
            if (currentConversationId) {
                openConversation(currentConversationId, currentReceiverId);
            }
        }, 1000);
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/dipraj-dhar/Downloads/Telegram Desktop/screnzo/resources/views/backend/layouts/chat/index.blade.php ENDPATH**/ ?>