<?php $__env->startSection('title', 'Role Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-12">
            <!-- Page header -->
            <div class="mb-5">
                <h3 class="mb-0 ">
                    <?php if(isset($role)): ?>
                        Edit Role
                    <?php else: ?>
                        Add Role
                    <?php endif; ?>
                </h3>
            </div>
        </div>
    </div>

    <div class="row">
        
        <div class="col-lg-5 col-12">
            <form action="<?php echo e(isset($role) ? route('role.update', $role->id) : route('role.store')); ?>" method="POST"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if(isset($role)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>

                <div class="card shadow-sm mb-2">
                    <div class="card-header text-white text-center ">
                        <h5 class="mb-0">
                            <?php if(isset($role)): ?>
                                <i class="bi bi-pencil-square me-2"></i> Edit Role
                            <?php else: ?>
                                <i class="bi bi-plus-circle me-2"></i> Add Role
                            <?php endif; ?>
                        </h5>
                    </div>
                </div>

                <div class="card mb-4">
                    <div class="card-body">

                        <!-- Role Name -->
                        <div class="mb-3">
                            <label class="form-label">Role Name</label>
                            <input type="text" name="name" class="form-control"
                                value="<?php echo e(old('name', $role->name ?? '')); ?>" placeholder="Enter role name">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <!-- Submit Button -->
                        <div class="d-grid">
                            <?php if(isset($role)): ?>
                                <button class="btn btn-success mb-4">Update</button>
                                <a href="<?php echo e(route('role.index')); ?>" class="btn btn-secondary">Back</a>
                            <?php else: ?>
                                <button class="btn btn-success mb-4">Create</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        
        <div class="col-lg-7 col-12">
            <div class="card mb-4">
                <div class="card">
                    <div class="card-header d-md-flex border-bottom-0">
                        <div class="flex-grow-1">
                            <label class="form-label fw-bold">Role List</label>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive table-card">
                            <table class="table table-striped table-hover align-middle text-nowrap table-centered mt-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>#</th>
                                        <th>Role Name</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i = 1; // Initialize counter
                                    ?>
                                    <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e($role->name); ?></td>

                                            <td>
                                                <!-- Edit Button -->
                                                <a href="<?php echo e(route('role.edit', $role->id)); ?>"
                                                    class="btn btn-sm btn-primary">Edit</a>

                                                <!-- Edit Permissions Button (Modal Trigger) -->
                                                <a href="<?php echo e(route('permission.edit', $role->id)); ?>"
                                                    class="btn btn-sm btn-info">
                                                    Assign Permissions
                                                </a>

                                                <!-- Delete Button -->
                                                <button type="button" data-url="<?php echo e(route('role.destroy', $role->id)); ?>"
                                                    class="btn-delete ms-3 btn btn-ghost btn-icon btn-sm rounded-circle texttooltip"
                                                    data-template="trashTwo">
                                                    <div class="btn btn-sm btn-danger"><span>Delete</span></div>
                                                </button>
                                            </td>



                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="4" class="text-center">No roles found</td>
                                        </tr>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dhard\Documents\Ompa27-WP_Monkey-laravel\resources\views/backend/layouts/role_permission/role/index.blade.php ENDPATH**/ ?>