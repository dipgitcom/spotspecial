<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4" style="background: linear-gradient(135deg, #f3f4f6 0%, #e5e9f7 100%); min-height:100vh;">
  <div class="row mb-4">
    <div class="col-lg-12">
      <div class="d-flex align-items-center justify-content-between rounded-3 p-4 mb-3 card-custom" style="box-shadow: 0 4px 24px rgba(36,46,63,0.09); background: #fff;">
        <div class="d-flex align-items-center gap-3">
          <div class="icon-circle bg-indigo text-white shadow-sm">
            <i class="bi bi-rocket" style="font-size: 1.5rem;"></i>
          </div>
          <div>
            <h2 class="mb-0 fw-bold text-primary">Welcome, <span class="text-dark"><?php echo e(Auth::user()->name); ?></span></h2>
            <div class="text-muted">Your professional admin dashboard overview</div>
          </div>
        </div>
        <div>
          <div id="digitalClock" class="digitalClock"></div>
        </div>
      </div>
    </div>
  </div>
  
 
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  function updateClock() {
    var clock = document.getElementById('digitalClock');
    if (!clock) return;
    var now = new Date();
    var h = String(now.getHours()).padStart(2, '0');
    var m = String(now.getMinutes()).padStart(2, '0');
    var s = String(now.getSeconds()).padStart(2, '0');
    clock.textContent = `${h}:${m}:${s}`;
  }
  setInterval(updateClock, 1000);
  updateClock();
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
.card-custom {
  background: #fff;
  border: 1px solid #e2e8f0;
  box-shadow: 0 4px 8px rgb(0 0 0 / 0.05);
  border-radius: 18px;
  transition: box-shadow 0.3s;
}
.card-custom:hover {
  box-shadow: 0 8px 20px rgb(0 0 0 / 0.12);
}
.icon-circle {
  width: 56px;
  height: 56px;
  background: #e0e7ff;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: inset 0 0 6px #c7d2fe;
}
.digitalClock {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  font-weight: 700;
  font-size: 1.5rem;
  color: #2563eb;
  user-select: none;
  min-width: 100px;
  text-align: center;
}
.bg-success-soft {
  background: #def7ec !important;
}
</style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dhard\Documents\Ompa27\resources\views/backend/layouts/dashboard.blade.php ENDPATH**/ ?>