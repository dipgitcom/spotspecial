
<?php $__env->startSection('title','Gallery Management'); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row">
        <!-- SECTION TITLE/SUBTITLE Edit -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5>Gallery Section Title & Subtitle</h5>
                </div>
                <div class="card-body">
                    <?php if(session('section_success')): ?>
                        <div class="alert alert-success"><?php echo e(session('section_success')); ?></div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('gallery-section.update')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-2">
                            <label class="form-label">Title</label>
                            <input name="title" value="<?php echo e($section->title ?? ''); ?>" class="form-control" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Subtitle</label>
                            <input name="subtitle" value="<?php echo e($section->subtitle ?? ''); ?>" class="form-control">
                        </div>
                        <button class="btn btn-success w-100">Update Section</button>
                    </form>
                </div>
            </div>
        </div>
        <!-- ADD IMAGE FORM -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5>Add Gallery Item</h5>
                </div>
                <div class="card-body">
                    <?php if(session('image_success')): ?>
                        <div class="alert alert-success"><?php echo e(session('image_success')); ?></div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('galleries.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-2">
                            <label class="form-label">Caption</label>
                            <input name="caption" class="form-control" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Image</label>
                            <input type="file" name="image" class="form-control">
                        </div>
                        <div class="mb-2">
                            <label class="form-label">Order</label>
                            <input type="number" name="order" class="form-control" value="1">
                        </div>
                        <button type="submit" class="btn btn-success w-100">Add Image</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- IMAGE LIST -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h5>All Gallery Images</h5>
                </div>
                <div class="card-body p-0">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success m-3"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Caption</th>
                                <th>Order</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($gallery->image): ?>
                                        <img src="<?php echo e(asset('storage/'.$gallery->image)); ?>" alt="img" width="80">
                                    <?php else: ?>
                                        <span class="text-muted">No image</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($gallery->caption); ?></td>
                                <td><?php echo e($gallery->order); ?></td>
                                <td>
                                    
                                    <form action="<?php echo e(route('galleries.destroy', $gallery)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-sm btn-danger" onclick="return confirm('Delete?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dhard\Documents\Ompa27\resources\views/backend/layouts/gallery/index.blade.php ENDPATH**/ ?>