
<?php $__env->startSection('title','Footer Settings'); ?>
<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <!-- Edit Copyright (left) -->
        <div class="col-lg-5">
            <div class="card mb-4">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0">Edit Footer Copyright</h5>
                </div>
                <form method="POST" action="<?php echo e(route('footer-settings.update', $footer->id)); ?>">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                        <?php endif; ?>
                        <div class="mb-3">
                            <label class="form-label">Copyright</label>
                            <input name="copyright" value="<?php echo e($footer->copyright); ?>" class="form-control" required>
                        </div>
                    </div>
                    <div class="card-footer text-end">
                        <button class="btn btn-success px-5">Update</button>
                    </div>
                </form>
            </div>
        </div>
        <!-- Edit Footer Links (right) -->
        <div class="col-lg-7">
            <div class="card h-100">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0">Footer Right-side Links</h6>
                </div>
                <div class="card-body p-0">
                    <table class="table table-sm mb-0">
                        <thead>
                        <tr><th>Order</th><th>Label</th><th>URL</th><th>Action</th></tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <form method="POST" action="<?php echo e(route('footer-links.update', $link->id)); ?>">
                                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                <td>
                                    <input type="number" name="order" value="<?php echo e($link->order); ?>" style="width:50px" class="form-control">
                                </td>
                                <td>
                                    <input name="label" value="<?php echo e($link->label); ?>" class="form-control">
                                </td>
                                <td>
                                    <input name="url" value="<?php echo e($link->url); ?>" class="form-control">
                                </td>
                                <td>
                                    <button class="btn btn-xs btn-info">Save</button>
                            </form>
                                    <form method="POST" action="<?php echo e(route('footer-links.destroy', $link->id)); ?>" style="display:inline;">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-xs btn-danger" onclick="return confirm('Delete?')">Del</button>
                                    </form>
                                </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <form method="POST" action="<?php echo e(route('footer-links.store')); ?>" class="d-flex gap-2">
                        <?php echo csrf_field(); ?>
                        <input name="order" type="number" value="1" class="form-control" style="width:60px" placeholder="Order">
                        <input name="label" class="form-control" placeholder="Label">
                        <input name="url" class="form-control" placeholder="URL">
                        <button class="btn btn-success btn-sm">Add Link</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dhard\Documents\Ompa27-WP_Monkey-laravel\resources\views/backend/layouts/footer/edit.blade.php ENDPATH**/ ?>