<?php $__env->startSection('title', 'User Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-12 mb-4">
            <h3 class="mb-0"><?php echo e(isset($user) ? 'Edit User' : 'Add User'); ?></h3>
        </div>
    </div>

    <div class="row">
        
        <div class="col-lg-5 col-12">
            <form action="<?php echo e(isset($user) ? route('user.update', $user->id) : route('user.store')); ?>" method="POST"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if(isset($user)): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>

                <div class="card shadow-sm">
                    <div class="card-header text-white text-center ">
                        <h5 class="mb-0">
                            <i class="bi <?php echo e(isset($user) ? 'bi-pencil-square' : 'bi-plus-circle'); ?> me-2"></i>
                            <?php echo e(isset($user) ? 'Edit User' : 'Add User'); ?>

                        </h5>
                    </div>
                    <div class="card-body">

                        
                        <div class="mb-3">
                            <label class="form-label">Name</label>
                            <input type="text" name="name" class="form-control"
                                value="<?php echo e(old('name', $user->name ?? '')); ?>" placeholder="Enter name">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control"
                                value="<?php echo e(old('email', $user->email ?? '')); ?>" placeholder="Enter email">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="mb-3">
                            <label class="form-label"><?php echo e(isset($user) ? 'New Password (optional)' : 'Password'); ?></label>
                            <input type="password" name="password" class="form-control" placeholder="Enter password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="mb-3">
                            <label
                                class="form-label"><?php echo e(isset($user) ? 'Confirm New Password' : 'Confirm Password'); ?></label>
                            <input type="password" name="password_confirmation" class="form-control"
                                placeholder="Confirm password">
                            <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="mb-3">
                            <label class="form-label">Photo</label>
                            <input type="file" name="photo" class="form-control" id="photoInput">
                            <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <?php if(isset($user) && $user->photo): ?>
                                <div class="mt-2">
                                    <label class="form-label d-block">Current Photo:</label>
                                    <img src="<?php echo e(asset($user->photo)); ?>" class="border p-1" width="100"
                                        alt="User Photo">
                                </div>
                            <?php endif; ?>

                            <div class="mt-2" id="newPhotoPreview" style="display:none;">
                                <label class="form-label d-block">New Photo Preview:</label>
                                <img id="previewImage" class="border p-1" width="100" alt="Preview">
                            </div>
                        </div>
                        
                        <?php if(isset($roles) && $roles->count() > 0): ?>
                            <div class="mb-3">
                                <label class="form-label">Assign Role</label>
                                <select name="roles[]" class="form-select select2" multiple>
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($role->id); ?>">
                                            <?php echo e($role->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['roles'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <?php endif; ?>

                        
                        <div class="d-grid">
                            <button class="btn btn-success mb-2"><?php echo e(isset($user) ? 'Update' : 'Create'); ?></button>
                            <?php if(isset($user)): ?>
                                <a href="<?php echo e(route('user.index')); ?>" class="btn btn-secondary">Back</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        
        <div class="col-lg-7 col-12">
            <div class="card mb-4">
                <div class="card-header">
                    <label class="form-label fw-bold mb-0">User List</label>
                </div>
                <div class="card-body">
                    <div class="table-responsive table-card">
                        <table id="usersTable" class="table table-striped table-hover align-middle text-nowrap">
                            <thead class="table-light">
                                <tr>
                                    <th style="width: 42px;">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="checkAllUsers">
                                        </div>
                                    </th>
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th style="min-width: 130px;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        // Preview Image
        document.getElementById('photoInput').addEventListener('change', function(event) {
            const previewContainer = document.getElementById('newPhotoPreview');
            const previewImage = document.getElementById('previewImage');
            const file = event.target.files[0];

            if (file) {
                const reader = new FileReader();
                reader.onload = e => {
                    previewImage.src = e.target.result;
                    previewContainer.style.display = 'block';
                }
                reader.readAsDataURL(file);
            } else {
                previewContainer.style.display = 'none';
            }
        });

        // DataTable Init
        $(function() {
            $('#usersTable').DataTable({
                processing: true,
                serverSide: true,
                searching: false,
                ordering: false,
                paging: false,
                lengthChange: false,
                info: false,

                ajax: '<?php echo e(route('user.index')); ?>',
                columns: [{
                        data: 'checkbox',
                        name: 'checkbox',
                        orderable: false,
                        searchable: false
                    },
                    {
                        data: 'DT_RowIndex',
                        name: 'DT_RowIndex'
                    },

                    {
                        data: 'name',
                        name: 'name'
                    },
                    {
                        data: 'email',
                        name: 'email'
                    },

                    {
                        data: 'action',
                        name: 'action',
                        orderable: false,
                        searchable: false
                    }
                ]
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dhard\Documents\Ompa27-WP_Monkey-laravel\resources\views/backend/layouts/role_permission/user/index.blade.php ENDPATH**/ ?>