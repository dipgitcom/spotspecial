<?php $__env->startSection('title', 'Tag'); ?>

<?php $__env->startSection('content'); ?>
<div class="card shadow-sm mb-2">
    <div class="card-header text-white text-center ">
        <h3 class="mb-0">Tag</h3>
    </div>
</div>

<div class="row">
    <!-- Tag List -->
    <div class="col-lg-7 col-12">
        <div class="card mb-4">
            <div class="card-body">
                <table class="table table-striped" id="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Tag Name</th>
                            <th>Slug</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Tag Add and Edit Form -->
    <div class="col-lg-5 col-12">
        <div id="addTagForm">
            <form id="addTag">
                <?php echo csrf_field(); ?>
                <div class="card shadow-sm mb-2">
                    <div class="card-header text-white text-center">
                        <h5 class="mb-0"><i class="bi bi-plus-circle me-2"></i> Add Tag</h5>
                    </div>
                </div>
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Tag Title</label>
                            <input type="text" name="tag_title" class="form-control" placeholder="Enter Tag Title">
                        </div>
                        <div class="d-flex justify-content-end">
                            <button type="submit" class="btn btn-outline-success mb-4 create_tag">Create</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <div id="editTagForm" class="d-none">
            <form id="editTag">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="tag_id">
                <div class="card shadow-sm mb-2">
                    <div class="card-header text-white text-center bg-warning">
                        <h5 class="mb-0"><i class="bi bi-pencil-square me-2"></i> Edit Tag</h5>
                    </div>
                </div>
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Tag Title</label>
                            <input type="text" name="tag_title" class="form-control" placeholder="Enter Tag Title">
                        </div>
                        <div class="d-flex justify-content-end gap-2 mt-3">
                            <button type="submit" class="btn btn-success update px-4">
                                <i class="bi bi-check-circle"></i> Update
                            </button>
                            <button type="button" onclick="hideEditForm()" class="btn btn-outline-secondary px-4">
                                <i class="bi bi-x-circle"></i> Cancel
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function() {
    let table = $('#table').DataTable({
    processing: true,
    serverSide: true,
    ajax: "<?php echo e(route('tags.list')); ?>",
    columns: [
        { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
        { data: 'tag_name', name: 'tag_name' },
        { data: 'slug', name: 'slug' },
        { data: 'action', name: 'action', orderable: false, searchable: false }
    ]
});
$(document).on('click', '.edit', function() {
    let id = $(this).data('id');
    let name = $(this).data('name');
    $('#addTagForm').addClass('d-none');
    $('#editTagForm').removeClass('d-none');
    $('#editTagForm input[name="tag_title"]').val(name);
    $('#editTagForm input[name="tag_id"]').val(id);
});


    // Add tag
    $('#addTag').submit(function(e) {
        e.preventDefault();
        let formData = new FormData(this);
        $.ajax({
            url: "<?php echo e(route('tags.store')); ?>",
            method: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response){
                if(response.success){
                    table.ajax.reload();
                    $('#addTag')[0].reset();
                    toastr.success(response.message);
                }else{
                    toastr.error('Validation failed.');
                }
            },
            error: function(){
                toastr.error('Something went wrong.');
            }
        });
    });

    // Update tag
    $('#editTag').submit(function(e) {
        e.preventDefault();
        let tag_id = $('#editTagForm input[name="tag_id"]').val();
        let formData = new FormData(this);

        $.ajax({
            url: `/admin/tags/update/${tag_id}`,
            method: "POST",
            data: formData,
            processData: false,
            contentType: false,
            success: function(response){
                if(response.success){
                    table.ajax.reload();
                    $('#editTag')[0].reset();
                    hideEditForm();
                    toastr.success(response.message);
                }else{
                    toastr.error('Validation failed.');
                }
            },
            error: function(){
                toastr.error('Something went wrong.');
            }
        });
    });

    // Delete tag
    $(document).on('click', '.delete', function(e){
        e.preventDefault();
        let tag_id = $(this).data('id');

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if(result.isConfirmed){
                $.ajax({
                    url: `/admin/tags/delete/${tag_id}`,
                    method: "POST",
                    data: {_token: '<?php echo e(csrf_token()); ?>'},
                    success: function(response){
                        if(response.success){
                            table.ajax.reload();
                            toastr.success(response.message);
                        }else{
                            toastr.error('Delete failed');
                        }
                    },
                    error: function(){
                        toastr.error('Something went wrong.');
                    }
                });
            }
        });
    });
});


function hideEditForm(){
    $('#editTagForm').addClass('d-none');
    $('#addTagForm').removeClass('d-none');
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/dipraj-dhar/Downloads/Telegram Desktop/screnzo/resources/views/backend/layouts/Tag/index.blade.php ENDPATH**/ ?>