<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="author" content="Codescandy" />
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> | Dash UI</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="" type="image/x-icon" />

    <!-- Global Styles -->
    <?php echo $__env->make('backend.partials.style', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Page Specific Styles -->
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body>
    <?php echo $__env->yieldContent('login'); ?>
    <main id="main-wrapper" class="main-wrapper">

        <?php if (! (Route::is(['login', 'register']))): ?>
            <?php echo $__env->make('backend.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('backend.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>

        <div id="app-content">
            <div class="app-content-area">
                <!-- Optional top spacing -->
                <div class="pt-10 pb-21 mt-n6 mx-n4"></div>

                <!-- Main Container -->
                <div class="container-fluid mt-n22">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
    </main>

    <!-- Scripts -->
    <?php if (! (Route::is('login'))): ?>
        <?php echo $__env->make('backend.partials.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>

    <!-- Page Specific Scripts -->
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH /home/dipraj-dhar/Downloads/Telegram Desktop/screnzo/resources/views/backend/master.blade.php ENDPATH**/ ?>