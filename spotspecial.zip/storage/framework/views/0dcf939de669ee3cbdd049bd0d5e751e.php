<?php $__env->startSection('title', 'Report Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-8 col-md-10">
            <div class="card shadow-sm mb-4">
                <div class="card-header text-white">
                    <h4 class="mb-0">Report Details - #<?php echo e($report->id); ?></h4>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <label class="col-sm-4 col-form-label fw-bold">Reporter:</label>
                        <div class="col-sm-8">
                            <span class="fs-6 text-dark"><?php echo e($report->reporter->name ?? 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-4 col-form-label fw-bold">Reported User:</label>
                        <div class="col-sm-8">
                            <span class="fs-6"><?php echo e($report->reportedUser->name ?? 'N/A'); ?></span>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-4 col-form-label fw-bold">Reason:</label>
                        <div class="col-sm-8">
                            <span class="badge bg-secondary fs-6"><?php echo e($report->report_reason); ?></span>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <label class="col-sm-4 col-form-label fw-bold">Status:</label>
                        <div class="col-sm-8">
                            <span class="badge 
                                <?php if($report->report_status == 'pending'): ?> bg-warning
                                <?php elseif($report->report_status == 'reviewed'): ?> bg-info
                                <?php elseif($report->report_status == 'resolved'): ?> bg-success
                                <?php else: ?> bg-secondary <?php endif; ?>
                                fs-6">
                                <?php echo e(ucfirst($report->report_status)); ?>

                            </span>
                        </div>
                    </div>
                    <div class="row mb-4">
                        <label class="col-sm-4 col-form-label fw-bold">Reported On:</label>
                        <div class="col-sm-8">
                            <span class="fs-6"><?php echo e($report->created_at->format('d M Y, h:i A')); ?></span>
                        </div>
                    </div>
                    <form id="report-status-form" method="POST" action="<?php echo e(route('layouts.reports.update', $report->id)); ?>">
    <?php echo csrf_field(); ?>
    <div class="row align-items-end">
        <div class="col-md-8">
            <label class="form-label fw-bold mb-1">Change Status</label>
            <select name="report_status" class="form-select">
                <option value="pending" <?php if($report->report_status == 'pending'): ?> selected <?php endif; ?>>Pending</option>
                <option value="reviewed" <?php if($report->report_status == 'reviewed'): ?> selected <?php endif; ?>>Reviewed</option>
                <option value="resolved" <?php if($report->report_status == 'resolved'): ?> selected <?php endif; ?>>Resolved</option>
            </select>
        </div>
        <div class="col-md-4 d-grid">
            <button type="submit" class="btn btn-success mt-3 mt-md-0">Update Status</button>
        </div>
    </div>
</form>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function() {
    $('#report-status-form').on('submit', function(e) {
        e.preventDefault(); // prevent normal form submit

        let form = $(this);
        let url = form.attr('action');
        let data = form.serialize();

        $.ajax({
            url: url,
            method: 'POST',
            data: data,
            success: function(res) {
                Swal.fire({
                    icon: 'success',
                    title: 'Updated!',
                    text: res.message,
                    timer: 1500,
                    showConfirmButton: false
                });

                // Optionally, update the status badge on the page
                let newStatus = form.find('select[name="report_status"]').val();
                let badge = form.closest('.card-body').find('.badge');
                badge.text(newStatus.charAt(0).toUpperCase() + newStatus.slice(1));
                badge.removeClass('bg-warning bg-info bg-success bg-secondary');
                if(newStatus == 'pending') badge.addClass('bg-warning');
                else if(newStatus == 'reviewed') badge.addClass('bg-info');
                else if(newStatus == 'resolved') badge.addClass('bg-success');
                else badge.addClass('bg-secondary');
            },
            error: function(xhr) {
                Swal.fire({
                    icon: 'error',
                    title: 'Error!',
                    text: xhr.responseJSON?.message || 'Update failed.'
                });
            }
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/dipraj-dhar/Downloads/Telegram Desktop/screnzo/resources/views/backend/layouts/reports/show.blade.php ENDPATH**/ ?>