<!-- navbar vertical -->
<div class="app-menu">
    <div class="navbar-vertical navbar nav-dashboard">
        <div class="h-100" data-simplebar>
            <!-- Brand logo -->
            <a class="navbar-brand" href="<?php echo e(route('dashboard')); ?>">
                <img
                    src="<?php echo e(isset($admin_setting->logo) ? asset($admin_setting->logo) : asset('uploads/default.png')); ?>" />
            </a>
            <!-- Navbar nav -->
            <ul class="navbar-nav flex-column" id="sideNavbar">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                        <i data-feather="bar-chart-2" class="nav-icon me-2 icon-xxs"></i>
                        Dashboard
                    </a>
                </li>




                



                <li class="nav-title" 





                




                <!-- Section title centered and bold -->
                <li class="nav-title"
                    style="font-weight:700; letter-spacing:2px; font-size:10x; color:#222; background:#f8f9fa; border-radius:6px; margin:11px 0; padding:7px 0; text-align:center;">
                    User Content Management
                </li>
                <li class="nav-item <?php echo e(request()->routeIs('post_manage.*') ? 'active' : ''); ?>">
                    <a class="nav-link has-arrow" data-bs-toggle="collapse" data-bs-target="#postManagementCollapse"
                        aria-expanded="<?php echo e(request()->routeIs('post_manage.*') ? 'true' : 'false'); ?>"
                        aria-controls="postManagementCollapse">
                        <i data-feather="file-text" class="nav-icon me-2 icon-xxs"></i>
                        Post
                    </a>
                    <div id="postManagementCollapse"
                        class="collapse <?php echo e(request()->routeIs('post_manage.*') ? 'show' : ''); ?>"
                        data-bs-parent="#sidebarMenu">
                        <ul class="nav flex-column ms-3">
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('post_manage.index') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('post_manage.index')); ?>">
                                    Posts
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="nav-item <?php echo e(request()->routeIs('admin.navbar.*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('admin.navbar.index')); ?>">
                        <i data-feather="sliders" class="nav-icon me-2 icon-xxs"></i>
                        Navbar Management
                    </a>
                </li>

                



                <!-- Sidebar report structure -->

                <li
                    class="nav-item <?php echo e(request()->routeIs('layouts.reports.*') || request()->routeIs('report_reason.*') ? 'active' : ''); ?>">
                    <a class="nav-link has-arrow" data-bs-toggle="collapse" data-bs-target="#reportsManagementCollapse"
                        aria-expanded="<?php echo e(request()->routeIs('layouts.reports.*') || request()->routeIs('report_reason.*') ? 'true' : 'false'); ?>"
                        aria-controls="reportsManagementCollapse">
                        <i data-feather="alert-triangle" class="nav-icon me-2 icon-xxs"></i>
                        Reports
                    </a>
                    <div id="reportsManagementCollapse"
                        class="collapse <?php echo e(request()->routeIs('layouts.reports.*') || request()->routeIs('report_reason.*') ? 'show' : ''); ?>"
                        data-bs-parent="#sideNavbar">
                        <ul class="nav flex-column ms-3">
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('layouts.reports.index') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('layouts.reports.index')); ?>">
                                    <i data-feather="list" class="nav-icon me-2 icon-xxs"></i>
                                    Reports
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('report_reason.index') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('report_reason.index')); ?>">
                                    <i data-feather="plus" class="nav-icon me-2 icon-xxs"></i>
                                    Report Reason Create
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="nav-item <?php echo e(request()->routeIs('feedback.*') ? 'active' : ''); ?>">
                    <a class="nav-link" href="<?php echo e(route('feedback.index')); ?>">
                        <i data-feather="message-square" class="nav-icon me-2 icon-xxs"></i>
                        Feedback
                    </a>
                </li>










                <li class="nav-title"
                    style="font-weight:700; letter-spacing:2px; font-size:10x; color:#222; background:#f8f9fa; border-radius:6px; margin:11px 0; padding:7px 0; text-align:center;">
                    System Content Management
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('dynamic-pages.index')); ?>">
                        <i class="bi bi-file-earmark-text fs-4 me-2"></i>
                        Dynamic Pages
                    </a>
                </li>

                


















                
                <li class="nav-item <?php echo e(request()->routeIs('user.*', 'role.*', 'permission.*') ? 'active' : ''); ?>">
                    <a class="nav-link has-arrow" data-bs-toggle="collapse" data-bs-target="#roleManagementCollapse"
                        aria-expanded="<?php echo e(request()->routeIs('users.*', 'roles.*', 'permissions.*') ? 'true' : 'false'); ?>"
                        aria-controls="roleManagementCollapse">
                        <i data-feather="shield" class="nav-icon me-2 icon-xxs"></i>
                        Role Management
                    </a>

                    <div id="roleManagementCollapse"
                        class="collapse <?php echo e(request()->routeIs('user.*', 'role.*', 'permission.*') ? 'show' : ''); ?>"
                        data-bs-parent="#sidebarMenu">

                        <ul class="nav flex-column ms-3">
                            
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('user.*') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('user.index')); ?>">
                                    Users
                                </a>
                            </li>

                            
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('role.*') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('role.index')); ?>">
                                    Roles
                                </a>
                            </li>

                            
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('permission.*') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('permission.index')); ?>">
                                    Permissions
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>




                
                <li class="nav-title"
                    style="font-weight:700; letter-spacing:2px; font-size:10x; color:#222; background:#f8f9fa; border-radius:6px; margin:11px 0; padding:7px 0; text-align:center;">
                    System Settings
                </li>
                <li
                    class="nav-item <?php echo e(request()->routeIs('profile.*', 'mail.*', 'system.*', 'admin.*') ? 'active' : ''); ?>">
                    <a class="nav-link has-arrow" href="" data-bs-toggle="collapse" data-bs-target="#settingsCollapse"
                        aria-expanded="<?php echo e(request()->routeIs('profile.*', 'mail.*', 'system.*', 'admin.*') ? 'true' : 'false'); ?>"
                        aria-controls="settingsCollapse">
                        <i data-feather="settings" class="nav-icon me-2 icon-xxs"></i>Settings
                    </a>

                    <div id="settingsCollapse"
                        class="collapse <?php echo e(request()->routeIs('profile.*', 'mail.*', 'system.*', 'admin.*') ? 'show' : ''); ?>"
                        data-bs-parent="#sidebarMenu">
                        <ul class="nav flex-column ms-3">
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('profile.index') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('profile.index')); ?>">
                                    Profile Setting
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('system.index') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('system.index')); ?>">
                                    Website Setting
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('admin.setting.index') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('admin.setting.index')); ?>">
                                    Admin Setting
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(request()->routeIs('mail.index') ? 'active' : ''); ?>"
                                    href="<?php echo e(route('mail.index')); ?>">
                                    Mail Setting
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                
                
            </ul>

        </div>
    </div>
</div><?php /**PATH C:\Users\dhard\Documents\ompa27\resources\views/backend/partials/sidebar.blade.php ENDPATH**/ ?>