<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ContactArea extends Model {
    protected $fillable = ['value', 'order'];
}
