<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class ServicePackageSection extends Model {
    protected $fillable = ['title','subtitle'];
}
